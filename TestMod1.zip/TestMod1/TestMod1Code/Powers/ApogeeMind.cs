﻿using BaseLib.Abstracts;
using MegaCrit.Sts2.Core.Combat;
using MegaCrit.Sts2.Core.Commands;
using MegaCrit.Sts2.Core.Entities.Cards;
using MegaCrit.Sts2.Core.Entities.Creatures;
using MegaCrit.Sts2.Core.Entities.Powers;
using MegaCrit.Sts2.Core.GameActions.Multiplayer;
using MegaCrit.Sts2.Core.HoverTips;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Models.Orbs;
using MegaCrit.Sts2.Core.Models.Powers;
using MegaCrit.Sts2.Core.ValueProps;
using System.Collections.Generic;
using System.Threading.Tasks;



namespace TestMod1.TestMod1Code.Powers
{
    // 1. Remove 'abstract' so it can be instantiated
    // 2. Keep 'sealed' if you don't want other mods inheriting from this
    public sealed class ApogeePower : CustomPowerModel
    {

        public override PowerType Type => !IsPositive ? PowerType.Debuff : PowerType.Buff;

        public override PowerStackType StackType => PowerStackType.Counter;

        // 3. Changed 'abstract' to a normal property with a default
        public AbstractModel? OriginModel => null;

        public PowerModel InternallyAppliedPower => ModelDb.Power<StrengthPower>();

        // 4. Changed 'virtual' to a normal property since the class is sealed
        private bool IsPositive => true;

        private int totalF;

        private int Sign => !IsPositive ? -1 : 1;

        protected override IEnumerable<IHoverTip> ExtraHoverTips => new IHoverTip[]
        {
            HoverTipFactory.FromPower<FocusPower>()
        };


        public override async Task AfterCardPlayed(PlayerChoiceContext context, CardPlay cardPlay)
        {
            // Always check for null on Owner/Player in case the power persists oddly
            if (cardPlay.Card.Owner == base.Owner?.Player && cardPlay.Card.Type == CardType.Attack)
            {
                await PowerCmd.Apply<FocusPower>(base.Owner, base.Amount, base.Owner, null);
                totalF += 1;
            }
        }

        public override async Task AfterTurnEnd(PlayerChoiceContext choiceContext, CombatSide side)
        {
            if (base.Owner != null && side == base.Owner.Side)
            {
                Flash();
                await PowerCmd.Remove(this);
                await PowerCmd.Apply<FocusPower>(base.Owner, -totalF , base.Owner, null);
            }
        }
    }
}