﻿using BaseLib.Abstracts;
using BaseLib.Utils;
using MegaCrit.Sts2.Core.Commands;
using MegaCrit.Sts2.Core.Entities.Cards;
using MegaCrit.Sts2.Core.GameActions.Multiplayer;
using MegaCrit.Sts2.Core.HoverTips;
using MegaCrit.Sts2.Core.Localization;
using MegaCrit.Sts2.Core.Localization.DynamicVars;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Models.CardPools;
using MegaCrit.Sts2.Core.Models.Orbs;
using MegaCrit.Sts2.Core.Models.Powers;
using MegaCrit.Sts2.Core.ValueProps;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;


namespace TestMod1.TestMod1Code.Cards.defect;

// zeus channel a shit ton of lightning


[Pool(typeof(DefectCardPool))]
public sealed class Zeus : CustomCardModel
{

    public override bool ShouldReceiveCombatHooks => true;
    //public override string CustomPortraitPath => "res://TestMod1/images/card_portraits/chugjug.png";

    public override IEnumerable<CardKeyword> CanonicalKeywords => (new CardKeyword[1]
{
        CardKeyword.Exhaust
});


    // Constructor: sets (cost, type, rarity, target, isPlayerCard)
    public Zeus()
        : base(1, CardType.Skill, CardRarity.Basic, TargetType.Self, true)
    {
    }

    // This defines the "Guts" of the card—what numbers it uses
    protected override IEnumerable<DynamicVar> CanonicalVars
    {
        get
        {
            return new DynamicVar[]
            {
                // 6 damage, categorized as a "Move" action for intent icons
                new DynamicVar("slots", 1m),
                new DynamicVar("lightning", 67m)
            };
        }
    }


    // This handles the "logic" when the card is dragged onto an enemy
    protected override async Task OnPlay(PlayerChoiceContext choiceContext, CardPlay cardPlay)
    {
        await CreatureCmd.TriggerAnim(base.Owner.Creature, "Cast", base.Owner.Character.CastAnimDelay);
        for (int i = 0; i < base.DynamicVars["lightning"].IntValue; i++)
        {
            await OrbCmd.Channel<LightningOrb>(choiceContext, base.Owner);
        }
    }
    protected override void OnUpgrade()
    {

        base.DynamicVars["lightning"].UpgradeValueBy(2m);
    }
}