﻿using BaseLib.Abstracts;
using BaseLib.Utils;
using MegaCrit.Sts2.Core.Commands;
using MegaCrit.Sts2.Core.Entities.Cards;
using MegaCrit.Sts2.Core.Entities.Creatures;
using MegaCrit.Sts2.Core.GameActions.Multiplayer;
using MegaCrit.Sts2.Core.HoverTips;
using MegaCrit.Sts2.Core.Localization;
using MegaCrit.Sts2.Core.Localization.DynamicVars;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Models.CardPools;
using MegaCrit.Sts2.Core.Models.Orbs;
using MegaCrit.Sts2.Core.Models.Powers;
using MegaCrit.Sts2.Core.ValueProps;
using MegaCrit.sts2.Core;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using MegaCrit.Sts2.Core.Entities.Rngs;


namespace TestMod1.TestMod1Code.Cards;




[Pool(typeof(ColorlessCardPool))]
public sealed class Roulette : CustomCardModel
{
    private int upgradeamount;
    public int cigarette;

    public override bool ShouldReceiveCombatHooks => true;
    public override CardMultiplayerConstraint MultiplayerConstraint => CardMultiplayerConstraint.MultiplayerOnly;
    public override string CustomPortraitPath => "res://TestMod1/images/card_portraits/chugjug.png";

    public override IEnumerable<CardKeyword> CanonicalKeywords => (new CardKeyword[1]
{
        CardKeyword.Exhaust
});


    // Constructor: sets (cost, type, rarity, target, isPlayerCard)
    public Roulette()
        : base(1, CardType.Skill, CardRarity.Basic, TargetType.AnyAlly, true)
    {
    }

    // This defines the "Guts" of the card—what numbers it uses
    protected override IEnumerable<DynamicVar> CanonicalVars
    {
        get
        {
            return new DynamicVar[]
            {
                // 6 damage, categorized as a "Move" action for intent icons
                new DynamicVar("Strength", 2m)
            };
        }
    }


    // This handles the "logic" when the card is dragged onto an enemy
    protected override async Task OnPlay(PlayerChoiceContext choiceContext, CardPlay cardPlay)
    {
        // 1. Initial Setup
        ArgumentNullException.ThrowIfNull(cardPlay.Target, "cardPlay.Target");

        
            Creature target = cardPlay.Target;
            Creature owner = base.Owner.Creature;
            int strength = base.DynamicVars["Strength"].IntValue;
            int currentHealth = owner.CurrentHp;
            int amountToLose = currentHealth - 1 + upgradeamount;
            int ocurrentHealth = target.CurrentHp;
            int oamountToLose = currentHealth - 1 + upgradeamount;

            await CreatureCmd.TriggerAnim(base.Owner.Creature, "Cast", base.Owner.Character.CastAnimDelay);
            // 2. The Gambler's Rolls
            var rng = base.Owner.RunState.Rng.Niche;
            int goalNumber = rng.NextInt(1, 2); // Random number 1-6
            int playerRoll = rng.NextInt(1, 2);
            int targetRoll = rng.NextInt(1, 2);

            // 3. Logic Branches
            bool playerWin = (playerRoll == goalNumber);
            bool targetWin = (targetRoll == goalNumber);

            if (playerWin)
            {
                // Player matched the goal: High damage to target
                await CreatureCmd.SetCurrentHp(target, 1);
            }
            else if (targetWin)
            {

                await CreatureCmd.Damage(choiceContext, base.Owner.Creature, amountToLose, ValueProp.Unblockable | ValueProp.Unpowered | ValueProp.Move, this);
            }
            else
            {
                // Both failed: Give both Strength
                await PowerCmd.Apply<StrengthPower>(owner, strength, owner, this);
                await PowerCmd.Apply<StrengthPower>(target, strength, owner, this);
            }
        }
    
    protected override void OnUpgrade()
    {

        base.DynamicVars["Strength"].UpgradeValueBy(1m);
    }
}