﻿using BaseLib.Abstracts;
using BaseLib.Extensions;
using Godot;
using TestMod1.TestMod1Code.Extensions;

namespace TestMod1.TestMod1Code.Powers
{
    public abstract class TestMod1Power : CustomPowerModel
    {
        //Loads from TestMod1/images/powers/your_power.png
        public override string CustomPackedIconPath => $"{Id.Entry.RemovePrefix().ToLowerInvariant()}.png".PowerImagePath();
        public override string CustomBigIconPath => $"{Id.Entry.RemovePrefix().ToLowerInvariant()}.png".BigPowerImagePath();
    }
}