﻿using BaseLib.Abstracts;
using BaseLib.Utils;
using MegaCrit.Sts2.Core.Commands;
using MegaCrit.Sts2.Core.Entities.Cards;
using MegaCrit.Sts2.Core.GameActions.Multiplayer;
using MegaCrit.Sts2.Core.HoverTips;
using MegaCrit.Sts2.Core.Localization.DynamicVars;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Models.CardPools;
using MegaCrit.Sts2.Core.Models.Powers;
using System.Collections.Generic;
using System.Threading.Tasks;
using TestMod1.TestMod1Code.Powers;

namespace TestMod1.TestMod1Code.Cards.defect
{
    [Pool(typeof(DefectCardPool))]
    public sealed class Reprogram : CustomCardModel
    {
        protected override IEnumerable<DynamicVar> CanonicalVars => (new DynamicVar[2]
        {
        new PowerVar<FocusPower>(0m),
        new PowerVar<ReprogramPower>(1m)
        });

        protected override IEnumerable<IHoverTip> ExtraHoverTips => (new IHoverTip[2]
        {
        HoverTipFactory.FromPower<FocusPower>(),
        HoverTipFactory.FromPower<StrengthPower>()
        });

        public Reprogram()
            : base(3, CardType.Power, CardRarity.Rare, TargetType.Self)
        {
        }

        protected override async Task OnPlay(PlayerChoiceContext choiceContext, CardPlay cardPlay)
        {
            await CreatureCmd.TriggerAnim(base.Owner.Creature, "Cast", base.Owner.Character.CastAnimDelay);
            await PowerCmd.Apply<FocusPower>(base.Owner.Creature, base.DynamicVars["FocusPower"].BaseValue, base.Owner.Creature, this);
            await PowerCmd.Apply<ReprogramPower>(base.Owner.Creature, base.DynamicVars["ReprogramPower"].BaseValue, base.Owner.Creature, this);
        }

        protected override void OnUpgrade()
        {
            base.DynamicVars["FocusPower"].UpgradeValueBy(1m);
        }
    }
}