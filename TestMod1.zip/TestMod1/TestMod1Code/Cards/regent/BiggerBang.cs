using BaseLib.Abstracts;
using BaseLib.Utils;
using MegaCrit.Sts2.Core.Commands;
using MegaCrit.Sts2.Core.Entities.Cards;
using MegaCrit.Sts2.Core.Entities.Players;
using MegaCrit.Sts2.Core.GameActions.Multiplayer;
using MegaCrit.Sts2.Core.HoverTips;
using MegaCrit.Sts2.Core.Localization.DynamicVars;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Models.CardPools;
using MegaCrit.Sts2.Core.Models.Cards;
using MegaCrit.Sts2.Core.Models.Powers;
using MegaCrit.Sts2.Core.ValueProps;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using MegaCrit.Sts2.Core.Nodes.Combat;
using MegaCrit.Sts2.Core.Combat;
using MegaCrit.Sts2.Core.Context;
using MegaCrit.Sts2.Core.Helpers;
using MegaCrit.Sts2.Core.Hooks;

namespace TestMod1.TestMod1Code.Cards.regent;


[Pool(typeof(RegentCardPool))]
public sealed class MyFirstAttack : CustomCardModel
{
    // Constructor: sets (cost, type, rarity, target, isPlayerCard)
    public override int CanonicalStarCost => 3;
    protected override bool IsPlayable
    {
        get
        {
            // Check if we have enough energy first
            if (!base.IsPlayable) return false;

            // Access the player through base.Owner.Player
            var player = base.Owner;
            if (player == null) return false;

            // Check the exhaust pile logic you had before PLUS the blade check
            bool hasBlade = GetSovereignBlades(player, includeExhausted: true).Any();

            return hasBlade;
        }
    }

    public MyFirstAttack()
		: base(4, CardType.Attack, CardRarity.Rare, TargetType.AllEnemies, true)
	{
	}
    public override string CustomPortraitPath => "res://TestMod1/images/card_portraits/biggerbang.png";

    // This defines the "Guts" of the card—what numbers it uses
    protected override IEnumerable<DynamicVar> CanonicalVars
	{
		get
		{
			return new DynamicVar[]
			{
				// 6 damage, categorized as a "Move" action for intent icons
				new DamageVar(700m, ValueProp.Move)
			};
		}
	}

	// This handles the "logic" when the card is dragged onto an enemy
	protected override async Task OnPlay(PlayerChoiceContext choiceContext, CardPlay cardPlay)
	{
		// Safety check to ensure a target was selected
		//ArgumentNullException.ThrowIfNull(cardPlay.Target, "cardPlay.Target");

        // The actual attack command
        await DamageCmd.Attack(base.DynamicVars.Damage.BaseValue).FromCard(this).TargetingAllOpponents(base.CombatState)
            .WithHitFx("vfx/vfx_starry_impact")
            .SpawningHitVfxOnEachCreature()
            .Execute(choiceContext);
    }

    // Handles what happens when you click 'Upgrade' at a rest site
    protected override void OnUpgrade()
	{
		// 6m + 3m = 9 damage total
		base.DynamicVars.Damage.UpgradeValueBy(77m);
	}
    private static IEnumerable<SovereignBlade> GetSovereignBlades(Player player, bool includeExhausted)
    {
        return player.PlayerCombatState.AllCards.Where(delegate (CardModel c)
        {
            if (!c.IsDupe)
            {
                if (!includeExhausted)
                {
                    CardPile? pile = c.Pile;
                    if (pile == null)
                    {
                        return true;
                    }
                    return pile.Type != PileType.Exhaust;
                }
                return true;
            }
            return false;
        }).OfType<SovereignBlade>();
    }
}
