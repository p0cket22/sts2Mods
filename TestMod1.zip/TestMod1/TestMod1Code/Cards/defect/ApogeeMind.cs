﻿using BaseLib.Abstracts;
using BaseLib.Utils;
using MegaCrit.Sts2.Core.Combat;
using MegaCrit.Sts2.Core.Commands;
using MegaCrit.Sts2.Core.Context;
using MegaCrit.Sts2.Core.Entities.Cards;
using MegaCrit.Sts2.Core.Entities.Creatures;
using MegaCrit.Sts2.Core.Entities.Players;
using MegaCrit.Sts2.Core.GameActions.Multiplayer;
using MegaCrit.Sts2.Core.Helpers;
using MegaCrit.Sts2.Core.Hooks;
using MegaCrit.Sts2.Core.HoverTips;
using MegaCrit.Sts2.Core.Localization;
using MegaCrit.Sts2.Core.Localization.DynamicVars;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Models.CardPools;
using MegaCrit.Sts2.Core.Models.Cards;
using MegaCrit.Sts2.Core.Models.Powers;
using MegaCrit.Sts2.Core.Nodes.Combat;
using MegaCrit.Sts2.Core.ValueProps;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TestMod1.TestMod1Code.Powers;

namespace TestMod1.TestMod1Code.Cards.defect;

// whenevever you play an attack trigger the passive of your left most orb channel 1 dark

[Pool(typeof(DefectCardPool))]
public sealed class ApogeeMind : CustomCardModel
{
    // Constructor: sets (cost, type, rarity, target, isPlayerCard)
    private int upgradeamount;
    public int cigarette;
    private LocString? _titleLocString;

    public override bool ShouldReceiveCombatHooks => true;

    public override IEnumerable<CardKeyword> CanonicalKeywords => (new CardKeyword[1]
{
        CardKeyword.Exhaust
});


    // Constructor: sets (cost, type, rarity, target, isPlayerCard)
    public ApogeeMind()
        : base(1, CardType.Skill, CardRarity.Uncommon, TargetType.Self, true)
    {
    }

    // This defines the "Guts" of the card—what numbers it uses
    protected override IEnumerable<DynamicVar> CanonicalVars
    {
        get
        {
            return new DynamicVar[]
            {
                // 6 damage, categorized as a "Move" action for intent icons
                new PowerVar<ApogeePower>(1m),
            };
        }
    }


    // This handles the "logic" when the card is dragged onto an enemy
    protected override async Task OnPlay(PlayerChoiceContext choiceContext, CardPlay cardPlay)
    {

        await CreatureCmd.TriggerAnim(base.Owner.Creature, "Cast", base.Owner.Character.CastAnimDelay);
        await PowerCmd.Apply<ApogeePower>(
        base.Owner.Creature,
        base.DynamicVars["ApogeePower"].IntValue,
        base.Owner.Creature,
        this
    );

    }
    protected override void OnUpgrade()
    {

        base.EnergyCost.UpgradeBy(-2);

    }
}
