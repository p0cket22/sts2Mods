﻿using BaseLib.Abstracts;
using MegaCrit.Sts2.Core.Combat;
using MegaCrit.Sts2.Core.Commands;
using MegaCrit.Sts2.Core.Entities.Powers;
using MegaCrit.Sts2.Core.HoverTips;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Models.Orbs;
using MegaCrit.Sts2.Core.Models.Powers;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace TestMod1.TestMod1Code.Powers
{
    public sealed class ReprogramPower : CustomPowerModel
    {
        public override PowerType Type => PowerType.Debuff;

        public override PowerStackType StackType => PowerStackType.Counter;

        protected override IEnumerable<IHoverTip> ExtraHoverTips => (new IHoverTip[1]
    {
        HoverTipFactory.FromPower<StrengthPower>()
    });

        public override async Task AfterSideTurnStart(CombatSide side, CombatState combatState)
        {
            if (side == base.Owner.Side)
            {
                Flash();
                await PowerCmd.Apply<StrengthPower>(base.Owner, -base.Amount, base.Owner, null);
                await PowerCmd.Apply<FocusPower>(base.Owner, base.Amount, base.Owner, null);
            }
        }
    }
}