﻿using BaseLib.Abstracts;
using BaseLib.Extensions;
using BaseLib.Utils;
using MegaCrit.Sts2.Core.Commands;
using MegaCrit.Sts2.Core.Entities.Cards;
using MegaCrit.Sts2.Core.Entities.Creatures;
using MegaCrit.Sts2.Core.GameActions.Multiplayer;
using MegaCrit.Sts2.Core.HoverTips;
using MegaCrit.Sts2.Core.Localization;
using MegaCrit.Sts2.Core.Localization.DynamicVars;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Models.CardPools;
using MegaCrit.Sts2.Core.Models.Powers;
using MegaCrit.Sts2.Core.ValueProps;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TestMod1.TestMod1Code.Extensions;


namespace TestMod1.TestMod1Code.Cards.necrobinder;




[Pool(typeof(NecrobinderCardPool))]
public sealed class NoMoreRoomInHell : CustomCardModel
{
    private int upgradeamount;
    private int upgradecost;
    public int cigarette;
    private LocString? _titleLocString;
    private string targettext= "Target creature";

    public override bool ShouldReceiveCombatHooks => true;
    protected override bool HasEnergyCostX => true;
    public override string CustomPortraitPath => "res://TestMod1/images/card_portraits/cigarettes.png";

    public override IEnumerable<CardKeyword> CanonicalKeywords => (new CardKeyword[1]
{
        CardKeyword.Exhaust
});
    public override TargetType TargetType
    {
        get
        {
            return base.IsUpgraded ? TargetType.AllEnemies : TargetType.AnyEnemy;
        }
    }

    // Constructor: sets (cost, type, rarity, target, isPlayerCard)
    public NoMoreRoomInHell()
        : base(0, CardType.Skill, CardRarity.Rare, TargetType.AnyEnemy, true)
    {
    }

    // This defines the "Guts" of the card—what numbers it uses
    protected override IEnumerable<DynamicVar> CanonicalVars
    {
        get
        {
            return new DynamicVar[]
            {
                // 6 damage, categorized as a "Move" action for intent icons
                new StringVar("Targets", targettext),
            };
        }
    }


    // This handles the "logic" when the card is dragged onto an enemy
    protected override async Task OnPlay(PlayerChoiceContext choiceContext, CardPlay cardPlay)
    {

        // 1. Set Health to 1
        // We calculate the amount needed to reduce health to 1, or use a direct SetHealth command
        int currentHealth = base.Owner.Creature.CurrentHp;
        int amountToLose = currentHealth-1 + upgradeamount;

        // 2. Give 500 Strength
        // Strength is a power identified by "Strength" or its specific PowerModel ID[cite: 2]
        await CreatureCmd.TriggerAnim(base.Owner.Creature, "Cast", base.Owner.Character.CastAnimDelay);
        await PowerCmd.Apply<DoomPower>(
                base.Owner.Creature,       // 1. The Target
                amountToLose,              // 2. The Amount
                base.Owner.Creature,       // 3. The Source
                this                       // 4. The Source Model (this card)
            );
        
        int xValue = ResolveEnergyXValue() + upgradecost;
        if (base.IsUpgraded)
        {
            await PowerCmd.Apply<VulnerablePower>(base.CombatState.HittableEnemies, 1m, base.Owner.Creature, this);
            for (int i = 0; i < xValue; i++)
            {
                await DamageCmd.Attack(amountToLose).FromOsty(base.Owner.Osty, this).TargetingAllOpponents(base.CombatState)
                .WithHitFx("vfx/vfx_attack_blunt", null, "blunt_attack.mp3")
                .Execute(choiceContext);
            }
        }
        else
        {
            await PowerCmd.Apply<VulnerablePower>(cardPlay.Target, 1m, base.Owner.Creature, this);
            for (int i = 0; i < xValue; i++)
            {
                await DamageCmd.Attack(amountToLose).FromOsty(base.Owner.Osty, this).Targeting(cardPlay.Target)
                .WithHitFx("vfx/vfx_attack_blunt", null, "blunt_attack.mp3")
                .Execute(choiceContext);
            }

        }

        
    }
    protected override void OnUpgrade()
    {
        targettext = "All creatures";
        upgradecost= upgradecost + 10;
        upgradeamount = upgradeamount + 1;
    }
}