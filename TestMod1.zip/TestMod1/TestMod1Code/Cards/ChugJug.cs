﻿using BaseLib.Abstracts;
using BaseLib.Utils;
using MegaCrit.Sts2.Core.Commands;
using MegaCrit.Sts2.Core.Entities.Cards;
using MegaCrit.Sts2.Core.GameActions.Multiplayer;
using MegaCrit.Sts2.Core.HoverTips;
using MegaCrit.Sts2.Core.Localization;
using MegaCrit.Sts2.Core.Localization.DynamicVars;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Models.CardPools;
using MegaCrit.Sts2.Core.Models.Orbs;
using MegaCrit.Sts2.Core.Models.Powers;
using MegaCrit.Sts2.Core.ValueProps;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;


namespace TestMod1.TestMod1Code.Cards;




[Pool(typeof(ColorlessCardPool))]
public sealed class ChugJug : CustomCardModel
{
    private int upgradeamount;
    public int cigarette;

    public override bool ShouldReceiveCombatHooks => true;
    public override string CustomPortraitPath => "res://TestMod1/images/card_portraits/chugjug.png";

    public override IEnumerable<CardKeyword> CanonicalKeywords => (new CardKeyword[1]
{
        CardKeyword.Exhaust
});


    // Constructor: sets (cost, type, rarity, target, isPlayerCard)
    public ChugJug()
        : base(1, CardType.Skill, CardRarity.Basic, TargetType.Self, true)
    {
    }

    // This defines the "Guts" of the card—what numbers it uses
    protected override IEnumerable<DynamicVar> CanonicalVars
    {
        get
        {
            return new DynamicVar[]
            {
                // 6 damage, categorized as a "Move" action for intent icons
                new DynamicVar("slots", 1m),
                new DynamicVar("Chugs", 2m)
            };
        }
    }


    // This handles the "logic" when the card is dragged onto an enemy
    protected override async Task OnPlay(PlayerChoiceContext choiceContext, CardPlay cardPlay)
    {
        await CreatureCmd.TriggerAnim(base.Owner.Creature, "Cast", base.Owner.Character.CastAnimDelay);
        await OrbCmd.AddSlots(base.Owner, base.DynamicVars["slots"].IntValue);
        for (int i = 0; i < base.DynamicVars["Chugs"].IntValue; i++)
        {
            await OrbCmd.Channel<FrostOrb>(choiceContext, base.Owner);
        }
    }
    protected override void OnUpgrade()
    {

        base.DynamicVars["Chugs"].UpgradeValueBy(1m);
    }
}