﻿using BaseLib.Abstracts;
using BaseLib.Extensions;
using BaseLib.Utils;
using MegaCrit.Sts2.Core.Commands;
using MegaCrit.Sts2.Core.Entities.Cards;
using MegaCrit.Sts2.Core.GameActions.Multiplayer;
using MegaCrit.Sts2.Core.HoverTips;
using MegaCrit.Sts2.Core.Localization;
using MegaCrit.Sts2.Core.Localization.DynamicVars;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Models.CardPools;
using MegaCrit.Sts2.Core.Models.Powers;
using MegaCrit.Sts2.Core.ValueProps;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TestMod1.TestMod1Code.Extensions;


namespace TestMod1.TestMod1Code.Cards.ironclad;



[Pool(typeof(IroncladCardPool))]
public sealed class Cigarettes : CustomCardModel
{
    private int upgradeamount;
    public int cigarette;
    private LocString? _titleLocString;

    public override bool ShouldReceiveCombatHooks => true;
    public override string CustomPortraitPath => "res://TestMod1/images/card_portraits/cigarettes.png";

    public override IEnumerable<CardKeyword> CanonicalKeywords =>(new CardKeyword[1]
{
        CardKeyword.Exhaust
});


    // Constructor: sets (cost, type, rarity, target, isPlayerCard)
    public Cigarettes()
        : base(1, CardType.Skill, CardRarity.Basic, TargetType.Self, true)
    {
    }

    // This defines the "Guts" of the card—what numbers it uses
    protected override IEnumerable<DynamicVar> CanonicalVars
    {
        get
        {
            return new DynamicVar[]
            {
                // 6 damage, categorized as a "Move" action for intent icons
                new DynamicVar("Power", 500m)
            };
        }
    }


    // This handles the "logic" when the card is dragged onto an enemy
    protected override async Task OnPlay(PlayerChoiceContext choiceContext, CardPlay cardPlay)
    {

        // 1. Set Health to 1
        // We calculate the amount needed to reduce health to 1, or use a direct SetHealth command
        int currentHealth = base.Owner.Creature.CurrentHp;
        int amountToLose = currentHealth - 1 + upgradeamount;
        await CreatureCmd.Damage(choiceContext, base.Owner.Creature, amountToLose, ValueProp.Unblockable | ValueProp.Unpowered | ValueProp.Move, this);

        // 2. Give 500 Strength
        // Strength is a power identified by "Strength" or its specific PowerModel ID[cite: 2]
        await CreatureCmd.TriggerAnim(base.Owner.Creature, "Cast", base.Owner.Character.CastAnimDelay);
        await PowerCmd.Apply<StrengthPower>(
                base.Owner.Creature,       // 1. The Target
                500m,                      // 2. The Amount
                base.Owner.Creature,       // 3. The Source
                this                       // 4. The Source Model (this card)
            );
    }
    protected override void OnUpgrade()
    {

        base.DynamicVars["Power"].UpgradeValueBy(9500m);
        upgradeamount = upgradeamount + 1;
    }
}