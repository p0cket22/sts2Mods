﻿using BaseLib.Abstracts;
using BaseLib.Utils;
using MegaCrit.Sts2.Core.Commands;
using MegaCrit.Sts2.Core.Entities.Cards;
using MegaCrit.Sts2.Core.Entities.Creatures;
using MegaCrit.Sts2.Core.GameActions.Multiplayer;
using MegaCrit.Sts2.Core.HoverTips;
using MegaCrit.Sts2.Core.Localization;
using MegaCrit.Sts2.Core.Localization.DynamicVars;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Models.CardPools;
using MegaCrit.Sts2.Core.Models.Powers;
using MegaCrit.Sts2.Core.MonsterMoves.Intents;
using MegaCrit.Sts2.Core.ValueProps;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TestMod1.TestMod1Code.Powers;


namespace TestMod1.TestMod1Code.Cards.ironclad;




[Pool(typeof(IroncladCardPool))]
public sealed class Medusa : CustomCardModel
{
    private int upgradeamount;
    public int cigarette;
    private LocString? _titleLocString;

    public override bool ShouldReceiveCombatHooks => true;

    public override IEnumerable<CardKeyword> CanonicalKeywords => (new CardKeyword[1]
{
        CardKeyword.Retain
});


    // Constructor: sets (cost, type, rarity, target, isPlayerCard)
    public Medusa()
        : base(3, CardType.Skill, CardRarity.Rare, TargetType.AllEnemies, true)
    {
    }

    // This defines the "Guts" of the card—what numbers it uses
    protected override IEnumerable<DynamicVar> CanonicalVars
    {
        get
        {
            return new DynamicVar[]
            {
                // 6 damage, categorized as a "Move" action for intent icons
                new PowerVar<MedusaStunPower>(1m),
            };
        }
    }


    // This handles the "logic" when the card is dragged onto an enemy
    protected override async Task OnPlay(PlayerChoiceContext choiceContext, CardPlay cardPlay)
    {
        
        await CreatureCmd.TriggerAnim(base.Owner.Creature, "Cast", base.Owner.Character.CastAnimDelay);
        foreach (Creature hittableEnemy in base.CombatState.HittableEnemies)
        {
            await CreatureCmd.Stun(hittableEnemy);
        }
        await PowerCmd.Apply<MedusaStunPower>(
        base.Owner.Creature,
        base.DynamicVars["MedusaStunPower"].IntValue,
        base.Owner.Creature,
        this
    );

    }
    protected override void OnUpgrade()
    {
        
        base.EnergyCost.UpgradeBy(-2);
        base.DynamicVars["MedusaStunPower"].UpgradeValueBy(1m);

    }
}