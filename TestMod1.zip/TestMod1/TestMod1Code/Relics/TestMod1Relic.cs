﻿using BaseLib.Abstracts;
using BaseLib.Extensions;
using Godot;
using TestMod1.TestMod1Code.Extensions;

namespace TestMod1.TestMod1Code.Relics
{
    public abstract class TestMod1Relic : CustomRelicModel
    {
        //TestMod1/images/relics
        public override string PackedIconPath => $"{Id.Entry.RemovePrefix().ToLowerInvariant()}.png".RelicImagePath();
        protected override string PackedIconOutlinePath => $"{Id.Entry.RemovePrefix().ToLowerInvariant()}_outline.png".RelicImagePath();
        protected override string BigIconPath => $"{Id.Entry.RemovePrefix().ToLowerInvariant()}.png".BigRelicImagePath();
    }
}
//