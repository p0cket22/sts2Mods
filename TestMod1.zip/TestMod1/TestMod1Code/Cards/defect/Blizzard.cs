﻿using BaseLib.Abstracts;
using BaseLib.Utils;
using MegaCrit.Sts2.Core.Combat;
using MegaCrit.Sts2.Core.Combat.History.Entries;
using MegaCrit.Sts2.Core.Commands;
using MegaCrit.Sts2.Core.Entities.Cards;
using MegaCrit.Sts2.Core.Entities.Creatures;
using MegaCrit.Sts2.Core.GameActions.Multiplayer;
using MegaCrit.Sts2.Core.HoverTips;
using MegaCrit.Sts2.Core.Localization.DynamicVars;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Models.CardPools;
using MegaCrit.Sts2.Core.Models.Orbs;
using MegaCrit.Sts2.Core.ValueProps;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TestMod1.TestMod1Code.Cards.defect;

[Pool(typeof(DefectCardPool))]
public sealed class Blizzard : CustomCardModel
{
    private const string _calculatedChannelsKey = "CalculatedChannels";

    protected override IEnumerable<IHoverTip> ExtraHoverTips => (new IHoverTip[2]
    {
        HoverTipFactory.Static(StaticHoverTip.Channeling),
        HoverTipFactory.FromOrb<FrostOrb>()
    });

    protected override IEnumerable<DynamicVar> CanonicalVars
    {
        get
        {
            return new DynamicVar[]
            {
            new CalculationBaseVar(0m),
            new DamageVar(2m, ValueProp.Move),
            new CalculationExtraVar(1m),

            new CalculatedVar("CalculatedChannels").WithMultiplier((CardModel card, Creature? _) =>
            {
                // Safely check if we are actually in a combat state first
                if (CombatManager.Instance?.History?.Entries == null)
                {
                    return 0; // Return 0 if viewed in the main menu/compendium
                }

                // If we are in combat, do the actual math safely
                return CombatManager.Instance.History.Entries
                    .OfType<OrbChanneledEntry>()
                    .Count(e => e.Actor?.Player == card.Owner && e.Orb is FrostOrb);
            })
            };
        }
    }

    public override IEnumerable<CardKeyword> CanonicalKeywords => (new CardKeyword[1]
{
        CardKeyword.Exhaust
});

    public Blizzard()
        : base(1, CardType.Attack, CardRarity.Uncommon, TargetType.AnyEnemy)
    {
    }

    protected override async Task OnPlay(PlayerChoiceContext choiceContext, CardPlay cardPlay)
    {
        await CreatureCmd.TriggerAnim(base.Owner.Creature, "Cast", base.Owner.Character.CastAnimDelay);
        int lightningChanneledCount = (int)((CalculatedVar)base.DynamicVars["CalculatedChannels"]).Calculate(cardPlay.Target);
        for (int i = 0; i < lightningChanneledCount; i++)
        {
            await DamageCmd.Attack(base.DynamicVars.Damage.BaseValue).FromCard(this).Targeting(cardPlay.Target)
            .WithHitFx("vfx/vfx_attack_slash")
            .Execute(choiceContext);
        }
    }

    protected override void OnUpgrade()
    {
        RemoveKeyword(CardKeyword.Exhaust);
        base.DynamicVars.Damage.UpgradeValueBy(2m);
    }
}
